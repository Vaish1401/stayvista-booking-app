const Attraction = () => {
  return <div>Attraction</div>;
};

export default Attraction;
