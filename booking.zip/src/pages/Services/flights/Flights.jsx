const Flights = () => {
  return <div>Flights</div>;
};

export default Flights;
