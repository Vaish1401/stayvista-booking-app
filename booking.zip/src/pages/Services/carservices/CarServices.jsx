const CarServices = () => {
  return <div>CarServices</div>;
};

export default CarServices;
