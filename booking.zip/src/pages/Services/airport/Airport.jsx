const Airport = () => {
  return <div>Airport</div>;
};

export default Airport;
