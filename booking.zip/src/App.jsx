import MainLayout from "./Layout/MainLayout";

function App() {
  return <MainLayout />;
}

export default App;
